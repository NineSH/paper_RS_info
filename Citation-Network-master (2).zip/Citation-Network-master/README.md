# Citation-Network
Build the citation network from the list of papers.

## Example
This is the example visualization of the network
![Visualization of the network](https://github.com/fahmisalman/Citation-Network/blob/master/Model/Net.png)

## Dataset
The dataset can be downloaded at https://aminer.org/citation
