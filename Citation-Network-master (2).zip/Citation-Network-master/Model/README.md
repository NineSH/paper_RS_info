# Model

This folder included:
- Nodes
- Edges
- Index
- Selecting Nodes
